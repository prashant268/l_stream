import streamlit as st
from streamlit_chat import message
from PIL import Image
import time
import utils2 as utils2
import subprocess
import warnings
import pandas as pd
import sqlite3
import numpy as np
warnings.filterwarnings("ignore", category=DeprecationWarning) 
import streamlit as st
from streamlit_extras.colored_header import colored_header
st.session_state.setdefault('history', [])

col1, col2, col3 = st.columns([1,2,1])

with col1:
    st.write("")

with col2:
    st.image('Logo.png', caption="Your Gateway to Enhanced Productivity. ", width=250, use_column_width=None, clamp=False, channels="RGB", output_format="auto")

with col3:
    st.write("")

if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    with st.chat_message(message["role"],avatar='/Users/prashant.kumar/Downloads/Axon/vanna.svg'):
        st.markdown(message["content"])

if prompt := st.chat_input("Ask Axon anything! Type your query here.."):
    st.chat_message("user",avatar='/Users/prashant.kumar/Downloads/Axon/vanna.svg').markdown(prompt)
    st.session_state.messages.append({"role": "user", "content": prompt})
    user_input=prompt
    if "@data" in user_input:
        with st.chat_message("assistant",avatar='/Users/prashant.kumar/Downloads/Axon/vanna.svg'):    
            with st.spinner('entered in sql mode...'):
                time.sleep(1)
                sql=utils2.generate_sql(user_input)
                
                db_path='SA1.sqlite'
                conn = sqlite3.connect(db_path)
                # try:
                df = pd.read_sql_query(sql, conn)
                plotly_code=utils2.generate_plotly_figure(user_input,sql,df)
                chain=utils2.result()
                final_response = chain.invoke(f"Based on the following information generate human redable response: {user_input},{df}")
                st.markdown(final_response)
                response = f"Response: {final_response}"
                st.markdown("DataFrame")
                st.table(df)
                st.plotly_chart(plotly_code, use_container_width=True)
    else:
        with st.chat_message("assistant",avatar='/Users/prashant.kumar/Downloads/Axon/vanna.svg'):    
            with st.spinner('entered in sql mode...'):
                response=utils2.user_input_chat(user_input)
                st.markdown(response)           
                
    st.session_state.messages.append({"role": "assistant", "content": response})
    st.markdown("""""", unsafe_allow_html=True)

