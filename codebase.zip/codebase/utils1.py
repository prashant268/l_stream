from dotenv import load_dotenv
load_dotenv()
from langchain.prompts.prompt import PromptTemplate
from langchain.memory import ConversationBufferWindowMemory
from langchain_community.utilities import SQLDatabase

from langchain_core.prompts import PromptTemplate

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.utilities import SQLDatabase
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.chains import create_sql_query_chain
from math import acos,cos,sin, radians
import configparser
import pandas as pd
import psycopg2
import os
import sqlite3
import utils2 as utils2
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import retrying
import psycopg2
import pandas as pd
from langchain.chains import ConversationChain
from sqlalchemy import create_engine,inspect
from langchain_community.vectorstores import FAISS
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.vectorstores import Chroma
import re

import openai
gemini_api_key = 'AIzaSyA5prR7R_xX3AljwfCjMsy_MNb3UMCFDIc'
google_api_key='AIzaSyA5prR7R_xX3AljwfCjMsy_MNb3UMCFDIc'
llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=gemini_api_key, 
                         convert_system_message_to_human=True, temperature=0.0)
chain=llm
from functools import wraps
from flask import Flask, jsonify, Response, request, redirect, url_for,render_template
import flask
import os
# from cache import MemoryCache
import plotly.graph_objects as go

app = Flask(__name__, static_url_path='')

# SETUP


def requires_cache(fields):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            id = request.args.get('id')

            if id is None:
                return jsonify({"type": "error", "error": "No id provided"})
            
            for field in fields:
                if cache.get(id=id, field=field) is None:
                    return jsonify({"type": "error", "error": f"No {field} found"})
            
            field_values = {field: cache.get(id=id, field=field) for field in fields}
            
            # Add the id to the field_values
            field_values['id'] = id

            return f(*args, **field_values, **kwargs)
        return decorated
    return decorator



def generate_sql(question):
    # question = flask.request.args.get('question')

    if question is None:
        return jsonify({"type": "error", "error": "No question provided"})
    if "@doc" in question:
       sql = "@doc document answer" #function call to generate document related stuff
    else:
        sql = utils2.generate_sql(question)    

    id = cache.generate_id(question=question)
    
    print(sql)
    cache.set(id=id, field='question', value=question)
    cache.set(id=id, field='sql', value=sql)

    return sql

@requires_cache(['sql'])
def run_sql(id: str, sql: str):
    if "@doc" not in sql: 
        try:
            
            db_path='SA1.sqlite'
            conn = sqlite3.connect(db_path)
            df = pd.read_sql_query(sql, conn)
            cache.set(id=id, field='df', value=df)
            return jsonify(
                {
                    "type": "df", 
                    "id": id,
                    "df": df.head(10).to_json(orient='records'),
                })

        except Exception as e:
            return jsonify({"type": "error", "error": str(e)})
    else:
        return jsonify({'type':'error',"error":"No sql to be performed"})    


def download_csv(id: str, df):
    csv = df.to_csv()
    return Response(
        csv,
        mimetype="text/csv",
        headers={"Content-disposition":
                 f"attachment; filename={id}.csv"})

@requires_cache(['df', 'question', 'sql'])
def generate_plotly_figure(id: str, df, question, sql):
    try:
        df_metadata=df.dtypes
        # final_response = chain.invoke(f"Based on the following information generate human readable response:{df},  user_input{user_input}")

        if question is not None:
            system_msg = f"The following is a pandas DataFrame that contains the results of the query that answers the question the user asked: '{question}'"
        else:
            system_msg = "The following is a pandas DataFrame "
        
        if sql is not None:
            system_msg += f"\n\nThe DataFrame was produced using this query: {sql}\n\n"
        
        system_msg += f"The following is information about the resulting pandas DataFrame 'df': \n{df_metadata}"
        system_msg+="Can you generate the Python plotly code to chart the results of the dataframe? Assume the data is in a pandas dataframe called 'df'. If there is only one value in the dataframe, use an Indicator. Respond with only Python code. Do not answer with any explanations -- just the code."
        
        message=chain.invoke(system_msg)
        message=message.content
        a = re.search(r'```python\n(.*?)\n```', message, re.DOTALL).group(1)
        a = a.replace("fig.show()", "fig_json = fig.to_json()")
        fig_json = None
        # print(a)
        local_namespace = {}
        exec(a, {'df': df}, local_namespace)

        # Get the updated value of fig_json from the local namespace
        fig_json = local_namespace.get('fig_json')
         
        cache.set(id=id, field='fig_json', value=fig_json)

        return jsonify(
            {
                "type": "plotly_figure", 
                "id": id,
                "fig": fig_json,
            })
    except Exception as e:
        # Print the stack trace
        import traceback
        traceback.print_exc()

        return jsonify({"type": "error", "error": str(e)})



@requires_cache(['df', 'question', 'sql'])
def generate_followup_questions(id: str, df, question, sql):
    # followup_questions = vn.generate_followup_questions(question=question, sql=sql, df=df)

    # cache.set(id=id, field='followup_questions', value=followup_questions)

    return jsonify(
        {
            "code":200
        })


@requires_cache(['question', 'sql', 'df', 'fig_json'])
def load_question(id: str, question, sql, df, fig_json):
    try:
        return jsonify(
            {
                "type": "question_cache", 
                "id": id,
                "question": question,
                "sql": sql,
                # "df": df.head(10).to_json(orient='records'),
                # "fig": fig_json,
                # "followup_questions": followup_questions,
            })

    except Exception as e:
        print("exception in load_question")
        return jsonify({"type": "error", "error": str(e)})


def get_question_history():
    return jsonify({"type": "question_history", "questions": cache.get_all(field_list=['question']) })

# @app.route('/')
# def root():
#     return app.send_static_file('index.html')

# @app.rout
