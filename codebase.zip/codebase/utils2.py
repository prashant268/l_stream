from dotenv import load_dotenv
load_dotenv()
from langchain.prompts.prompt import PromptTemplate
from langchain.memory import ConversationBufferWindowMemory
from langchain_community.utilities import SQLDatabase

from langchain_core.prompts import PromptTemplate

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.utilities import SQLDatabase
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.chains import create_sql_query_chain
from math import acos,cos,sin, radians
import configparser
import pandas as pd
import psycopg2
import os
import sqlite3
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import retrying
import psycopg2
import pandas as pd
from langchain.chains import ConversationChain
from sqlalchemy import create_engine,inspect
from langchain_community.vectorstores import FAISS
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import OpenAIEmbeddings
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.vectorstores import Chroma
import re
import utils as utils
gemini_api_key = 
google_api_key=
llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=gemini_api_key, 
                         convert_system_message_to_human=True, temperature=0.0)
chain=llm

def result():
    output_parser = StrOutputParser()
    chain = llm | output_parser
    return chain

def generate_plotly_figure(question, sql,df  ): 
        df_metadata=df.dtypes
        # final_response = chain.invoke(f"Based on the following information generate human readable response:{df},  user_input{user_input}")

        if question is not None:
            system_msg = f"The following is a pandas DataFrame that contains the results of the query that answers the question the user asked: '{question}'"
        else:
            system_msg = "The following is a pandas DataFrame "
        
        if sql is not None:
            system_msg += f"\n\nThe DataFrame was produced using this query: {sql}\n\n"
        
        system_msg += f"The following is information about the resulting pandas DataFrame 'df': \n{df_metadata}"
        system_msg+="Can you generate the Python plotly code to chart the results of the dataframe? Assume the data is in a pandas dataframe called 'df'. If there is only one value in the dataframe, use an Indicator. Respond with only Python code. Do not answer with any explanations -- just the code."
        
        message=chain.invoke(system_msg)
        message=message.content
        a = re.search(r'```python\n(.*?)\n```', message, re.DOTALL).group(1)
        a = a.replace("fig.show()", "")
        fig_json = None
        # print(a)
        local_namespace = {}
        exec(a, {'df': df}, local_namespace)

        # Get the updated value of fig_json from the local namespace
        fig = local_namespace.get('fig')

        return fig


from langchain_core.prompts import (
    ChatPromptTemplate,
    FewShotPromptTemplate,
    MessagesPlaceholder,
    PromptTemplate,
    SystemMessagePromptTemplate,
)
def generate_sql(user_input):
    df=pd.read_csv("examples.csv")
    examples=df.to_dict(orient='records')
    example_selector = SemanticSimilarityExampleSelector.from_examples(
        examples,
        GoogleGenerativeAIEmbeddings(google_api_key=google_api_key,model = "models/embedding-001"),
        Chroma,
        k=1,
    )
    example_prompt = PromptTemplate(
        input_variables=[ "Human"],
        template="Human: {Human}\nSQL: {SQL}",
    )
    
    similar_prompt = FewShotPromptTemplate(
        # We provide an ExampleSelector instead of examples.
        example_selector=example_selector,
        example_prompt=example_prompt,
       
        prefix="",
        suffix="",
        input_variables=[ "Human"],
    )
    a=similar_prompt.format(Human=user_input)
    PROMPT_TEMPLATE = """You are a chatbot named AXON which generates sql query stored in "sqlite". 
    Dont generate response if question is not related to database respond with "i dont know".
    Your company maintains two database tables: "invoice" and "delivery" always use these table only
    Dont do any UPDATE,INSERT, DELETE query generation.
        invoice which has column names as following:
        ['invoiceno it is invoice id 
        'sales_order_no it is sales order number
        'amount' it is the price of items,currency type is M.A.D
        'invoicedate' date of invoice
        'itemname' it is name of item
        'plant'-delivery plant number
        'quantity'-it is quantity of orders
        'net_weight'-it is net weight of orders
        'customername'-it is customer name
        'customerid'-unique id for each customers
        ]
        second table is delivery:
        ['date_of_delivery',
          'tripno':this is trip id number,
            'invoiceno' this is invoice id , 
            'deliveryexecutiveempcode' this is delivery executive employee code,
            'deliveryexecutivename' this is delivery executive employee name, 
            'customerid' this is unique customer id when not asked for name use this column always, 
            'out_for_delivery'-this is column showing if delivery started from source or not,
            'delivery_status'-this column show is item delivered or not,
            'on_time_delivery'-this have three values 'late', 'on-time','nan'.
            ]
        Dont include ```, ```sql and \n in the output.
        {history}
    Human: {input}
    
    SQL:
    Instructions:
                Alway do a distinct count on customer id when question is related to customers
                Question: {input}
                Given an input question, first create a syntactically correct
                dialect sql query to run.
                double check the sql query generated should not have ```, ```sql and \n or any special character at prefix or suffix.
                Relevant pieces of previous conversation:
                Dont include ```, ```sql and \n in the output.
    
    
    examples:
    
    
    """
    print("example selected",a)
    PROMPT_TEMPLATE+=a
    PROMPT = PromptTemplate(
        input_variables=["input", "history"],
        template=PROMPT_TEMPLATE
    )
    memory = ConversationBufferMemory(memory_key="history")
    conversation = ConversationChain(
        llm=llm,
        verbose=False,
        prompt=PROMPT,
        memory=memory
    )
    response=conversation.predict(input=user_input) #returns sql data
    class SQLExtractor:
        def __init__(self):
            pass
        def extract_sql(self, llm_response: str) -> str:
            # If the llm_response contains a markdown code block, with or without the sql tag, extract the sql from it
            sql = re.search(r"```sql\n SQL:(.*)```", llm_response, re.DOTALL)
            if sql:
                # Log the original response and the extracted SQL
                print(f"Output from LLM: {llm_response} \nExtracted SQL: {sql.group(1)}")
                return sql.group(1)
    
            sql = re.search(r"```(.*)```", llm_response, re.DOTALL)
            if sql:
                # Log the original response and the extracted SQL
                print(f"Output from LLM: {llm_response} \nExtracted SQL: {sql.group(1)}")
                return sql.group(1)
    
            return llm_response
    
        def is_sql_valid(self, sql: str) -> bool:
            if "SELECT" in sql.upper():
                return True
            else:
                return False
    
    extractor = SQLExtractor()
    extracted_sql = extractor.extract_sql(response)
    
    if extractor.is_sql_valid(extracted_sql):
        try:
            sql=extracted_sql.split('SQL:', 1)[1]
        except:
            sql=extracted_sql
        return(sql)
    else:
        return response
    
def get_conversational_chain():  
            prompt_template = """
            Answer the question as detailed as possible from the provided context, make sure to provide all the details. 
            don't give wrong answers or made up answers by hallucination.
            \n\n
            Context:\n {context}?\n
            Question: \n{question}\n

            Answer:
            """
            model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0, max_tokens=300,request_timeout=3)
            prompt = PromptTemplate(template = prompt_template, input_variables = ["context", "question"])
            chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
            return chain

def user_input_chat(user_question):
    embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")
    new_db = FAISS.load_local("faiss_prod_inex", embeddings)
    docs = new_db.similarity_search(user_question)
    chain = get_conversational_chain()
    response = chain(
        {"input_documents":docs, "question": user_question}
        , return_only_outputs=True)
    return response["output_text"]             